/** @file common.h
 *
 * @brief Common definitions
 *
 */

#include "common.h"

void
display_bytes (char const * const prefix, void const * const p_var, size_t const var_len)
{
    unsigned char chr;

    printf("%s", prefix);
    for (size_t index = 0u; index < var_len; index++)
    {
        chr = ((unsigned char*)p_var)[index];
        printf("%02hhx ", chr);
    }
    printf("\n");
}

/*** end of file ***/
