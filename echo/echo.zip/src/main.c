/** @file main.c
 *
 * @brief Main source
 *
 */

#include "main.h"

int
main (int argc, char * argv[])
{
    status_t status;

    int opt;
    bool b_verbose = false;
    uint16_t server_port = 0u;
    int backlog = DEFAULT_BACKLOG;

    while (-1 != (opt = getopt(argc, argv, "vp:b:")))
    {
        // Enforce command line integer sizes
        uint64_t temp_uint;
        int64_t temp_int;

        switch (opt)
        {
            case 'v':
                b_verbose = true;
                break;

            case 'p':
                temp_uint = strtoul(optarg, NULL, 10);
                if (MAX_PORT >= temp_uint)
                {
                    server_port = (uint16_t)temp_uint;
                }
                else
                {
                    fprintf(stderr, "Port must be [1-65535]\n");
                    status = STATUS_FAILURE;
                    goto cleanup;
                }
                break;

            case 'b':
                temp_int = strtol(optarg, NULL, 10);
                if ((1 <= temp_int) && (INT_MAX >= temp_int))
                {
                    backlog = (int)temp_int;
                }
                else
                {
                    fprintf(stderr, "Backlog must be [1-%d]\n", INT_MAX);
                    status = STATUS_FAILURE;
                    goto cleanup;
                }
                break;

            default:
                fprintf(stderr, "Usage: %s [-v] -p port [-b backlog]\n", argv[0]);
                status = STATUS_FAILURE;
                goto cleanup;
        }
    }

    if (optind != argc)
    {
        fprintf(stderr, "Unexpected positional arguments\n");
        status = STATUS_FAILURE;
        goto cleanup;
    }

    if (0u == server_port)
    {
        fprintf(stderr, "Argument -p port is required (positive integer)\n");
        fprintf(stderr, "Usage: %s [-v] -p port [-b backlog]\n", argv[0]);
        status = STATUS_FAILURE;
        goto cleanup;
    }

    struct sigaction sigact;

    memset(&sigact, 0, sizeof(sigact));
    sigact.sa_handler = reap_children;
    sigact.sa_flags = SA_RESTART;
    sigemptyset(&sigact.sa_mask);

    if (-1 == sigaction(SIGCHLD, &sigact, NULL))
    {
        perror("sigaction");
        status = STATUS_FAILURE;
        goto cleanup;
    }

    session_t session =
    {
        .server_port = server_port,
        .client_port = 0u,
        .server_sockfd = -1,
        .client_sockfd = -1,
        .backlog = backlog,
        .b_verbose = b_verbose
    };

    status = server_socket(&session);
    if (STATUS_SUCCESS != status)
    {
        goto cleanup;
    }

    status = client_socket(&session);
    if (STATUS_SUCCESS != status)
    {
        goto cleanup;
    }

    close(session.server_sockfd);
    status = STATUS_SUCCESS;
    goto cleanup;

cleanup:
    if (STATUS_SUCCESS != status)
    {
        fprintf(stderr, "errno: %d\n", errno);
    }

    return status;
}

/*** end of file ***/
