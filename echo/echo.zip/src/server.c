/** @file server.c
 *
 * @brief Echo server
 *
 * @par
 * Basic TCP server
 */

#include "server.h"

status_t
server_socket (session_t * p_session)
{
    status_t status;
    struct sockaddr_in server_addr;

    int yes = 1;

    if (NULL == p_session)
    {
        status = STATUS_NULL_ARG;
        goto cleanup;
    }

    int server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == server_sockfd)
    {
        perror("socket");
        status = STATUS_SOCKET_FAILURE;
        goto cleanup;
    }

    if (-1 == setsockopt(server_sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes)))
    {
        perror("setsockopt");
        status = STATUS_SOCKET_FAILURE;
        goto cleanup;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(p_session->server_port);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    // Catch privileged port as non-root user
    if ((1024u > (p_session->server_port)) && (0 != geteuid()))
    {
        fprintf(stderr, "Cannot bind to privileged port %hu [1-1023] as non-root user\n", p_session->server_port);
        status = STATUS_FAILURE;
        goto cleanup;
    }

    if (-1 == bind(server_sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)))
    {
        perror("bind");
        close(server_sockfd);
        status = STATUS_SOCKET_FAILURE;
        goto cleanup;
    }

    if (-1 == listen(server_sockfd, p_session->backlog))
    {
        perror("listen");
        close(server_sockfd);
        status = STATUS_SOCKET_FAILURE;
        goto cleanup;
    }

    if (p_session->b_verbose)
    {
        char ipstr[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &(server_addr.sin_addr.s_addr), ipstr, sizeof(ipstr));
        printf("Listening on %s:%hu\n", ipstr, p_session->server_port);
        printf("server_sockfd: %d\n", server_sockfd);
    }

    p_session->server_sockfd = server_sockfd;
    status = STATUS_SUCCESS;
    goto cleanup;

cleanup:
    return status;
}

status_t
client_socket (session_t * p_session)
{
    status_t status;
    int client_sockfd;

    if (NULL == p_session)
    {
        status = STATUS_NULL_ARG;
        goto cleanup;
    }

    // Accept loop
    while (1)
    {
        struct sockaddr_in client_addr;

        socklen_t sin_size = sizeof(client_addr);
        client_sockfd = accept(p_session->server_sockfd, (struct sockaddr*)&client_addr, &sin_size);
        if (-1 == client_sockfd)
        {
            if (EINTR == errno)
            {
                continue;
            }

            perror("accept");
            continue;
        }

        uint16_t client_port = ntohs(client_addr.sin_port);

        if (p_session->b_verbose)
        {
            char ipstr[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &(client_addr.sin_addr.s_addr), ipstr, sizeof(ipstr));
            printf("Connection received from %s:%hu\n", ipstr, client_port);
            printf("client_sockfd: %d\n", client_sockfd);
        }

        // TODO: Epoll for client socket events instead of fork

        pid_t pid = fork();

        switch (pid)
        {
            case -1:
                // Error, no fork
                perror("fork");
                close(client_sockfd);
                status = STATUS_FAILURE;
                goto cleanup;

            case 0:
                // Child process
                close(p_session->server_sockfd);
                p_session->client_port = client_port;
                p_session->client_sockfd = client_sockfd;
                handle_client(p_session);
                close(client_sockfd);
                _Exit(STATUS_SUCCESS);

            default:
                // Parent process
                close(client_sockfd);
                continue;
        }
    }

    status = STATUS_SUCCESS;
    goto cleanup;

cleanup:
    return status;
}

status_t
handle_client (session_t * p_session)
{
    status_t status;
    uint32_t size;
    char recv_buf[MAX_PAYLOAD_SIZE];

    if (NULL == p_session)
    {
        status = STATUS_NULL_ARG;
        goto cleanup;
    }

    // Receive loop
    while (1)
    {
        size = 1u;
        status = recvall(p_session->client_sockfd, recv_buf, size);
        if (STATUS_RECV_FAILURE == status)
        {
            perror("recvall");
            goto cleanup;
        }
        else if (STATUS_CLIENT_DISCONNECT == status)
        {
            if (p_session->b_verbose)
            {
                printf("Client disconnected\n");
            }
            goto cleanup;
        }

        if (p_session->b_verbose)
        {
            printf("Received %u bytes: ", size);
            fwrite(recv_buf, 1u, size, stdout);
            printf("\n");
        }

        // TODO: Handle request

        status = sendall(p_session->client_sockfd, recv_buf, size);
        if (STATUS_SEND_FAILURE == status)
        {
            perror("sendall");
            goto cleanup;
        }

        if (p_session->b_verbose)
        {
            printf("Sent %u bytes: ", size);
            fwrite(recv_buf, 1u, size, stdout);
            printf("\n");
        }
    }

    goto cleanup;

cleanup:
    return status;
}

status_t
sendall (int sockfd, char const * const buf, size_t size)
{
    status_t status;

    size_t total = 0u;

    while (total < size)
    {
        ssize_t sent = send(sockfd, buf + total, size - total, 0);
        if (-1 == sent)
        {
            if (EINTR == errno)
            {
                continue;
            }

            status = STATUS_SEND_FAILURE;
            goto cleanup;
        }
        else if (0 == sent)
        {
            errno = EPIPE;
            status = STATUS_SEND_FAILURE;
            goto cleanup;
        }

        total += (size_t)sent;
    }

    status = STATUS_SUCCESS;
    goto cleanup;

cleanup:
    return status;
}

status_t
recvall (int sockfd, char * const buf, size_t size)
{
    status_t status;

    size_t total = 0u;

    while (total < size)
    {
        ssize_t recvd = recv(sockfd, buf + total, size - total, 0);
        if (-1 == recvd)
        {
            if (EINTR == errno)
            {
                continue;
            }

            status = STATUS_RECV_FAILURE;
            goto cleanup;
        }
        else if (0 == recvd)
        {
            status = STATUS_CLIENT_DISCONNECT;
            goto cleanup;
        }

        total += (size_t)recvd;
    }

    status = STATUS_SUCCESS;
    goto cleanup;

cleanup:
    return status;
}

void
reap_children (int signo)
{
    int saved_errno = errno;
    (void)signo;

    while (0 < waitpid(-1, NULL, WNOHANG))
    {
    }

    errno = saved_errno;

    return;
}

/*** end of file ***/
