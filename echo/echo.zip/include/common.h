/** @file common.h
 *
 * @brief Common definitions
 *
 */

#ifndef COMMON_H
#define COMMON_H

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum status
{
    STATUS_SUCCESS           = EXIT_SUCCESS,
    STATUS_FAILURE           = EXIT_FAILURE,
    STATUS_NULL_ARG          = 2,
    STATUS_SOCKET_FAILURE    = 3,
    STATUS_SEND_FAILURE      = 4,
    STATUS_RECV_FAILURE      = 5,
    STATUS_CLIENT_DISCONNECT = 6,
    STATUS_ALLOC_FAILURE     = 7
} status_t;

/*!
 * @brief Display variable bytes in hex
 *
 * @param[in] prefix  String to print before
 * @param[in] p_var   Pointer to variable
 * @param[in] var_len Variable length
 *
 * @return void
 */
void display_bytes(char const * const prefix, void const * const p_var, size_t const var_len);

#endif /* COMMON_H */

/*** end of file ***/
