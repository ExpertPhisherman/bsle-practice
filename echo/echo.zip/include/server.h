/** @file server.c
 *
 * @brief Echo server
 *
 * @par
 * Basic TCP server
 */

#ifndef SERVER_H
#define SERVER_H

#define MAX_PORT 65535
#define DEFAULT_BACKLOG 10
#define MAX_PAYLOAD_SIZE 4096

#include "common.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <pthread.h>

typedef struct request
{
    uint8_t opcode;
    uint32_t size;
    unsigned char * p_payload;
} request_t;

typedef struct response
{
    uint8_t status;
    uint32_t size;
    unsigned char * p_payload;
} response_t;

typedef struct session
{
    uint16_t server_port;
    uint16_t client_port;
    int server_sockfd;    // Server listening socket file descriptor
    int client_sockfd;    // Client connected socket file descriptor
    int backlog;
    bool b_verbose;
} session_t;

/*!
 * @brief Prepare, bind, and listen on socket
 *
 * @param[in] p_session Pointer to session
 *
 * @return Status of operation
 */
status_t server_socket(session_t * p_session);

/*!
 * @brief Accept and establish connection on socket
 *
 * @param[in] p_session Pointer to session
 *
 * @return Status of operation
 */
status_t client_socket(session_t * p_session);

/*!
 * @brief Handle client session
 *
 * @param[in] p_session Pointer to session
 *
 * @return Status of operation
 */
status_t handle_client(session_t * p_session);

/*!
 * @brief Send all data to client
 *
 * @param[in] sockfd Socket file descriptor to send data to
 * @param[in] buf    Buffer to send
 * @param[in] size   Size of buffer to send
 *
 * @return Status of operation
 */
status_t sendall(int sockfd, char const * const buf, size_t size);

/*!
 * @brief Receive all data from client
 *
 * @param[in] sockfd Socket file descriptor to receive data from
 * @param[in] buf    Buffer to receive into
 * @param[in] size   Size of buffer to receive into
 *
 * @return Status of operation
 */
status_t recvall(int sockfd, char * const buf, size_t size);

/*!
 * @brief Reap zombie child processes
 *
 * @param[in] signo Signal number
 *
 * @return void
 */
void reap_children(int signo);

#endif /* SERVER_H */

/*** end of file ***/
